﻿public enum DeathCause
{
    All,
    Time,
    Сollision,
    Kill
}
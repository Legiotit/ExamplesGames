﻿public enum EntityType
{
    Tower,
    Wall,
    Generator
}
﻿public enum Status
{
    Ally,
    Enemy,
    Neutral
}